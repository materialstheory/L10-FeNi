#! /bin/bash

for i in */;
do 
	echo $i;
	cd $i
	ls
	#sed -i '/NUPDOWN = 0/d' INCAR  
	rm vasprun.xml WAVECAR PROCAR CHG CHGCAR CONTCAR DOSCAR EIGENVAL job.* log OSZICAR OUTCAR PCDAT REPORT XDATCAR IBZKPT out.* err.* script.sh SUMMARY.dat INCAR KPOINTS POTCAR script_daint.sh script_euler.sh
	cd ..
done
